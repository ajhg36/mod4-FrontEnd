import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
import Login from './Components/Login';
import Mensaje from './Components/Mensaje';

function App() {

  const [mensaje, setMensaje] = useState('');

  const getLogin = (user, password) => {
  const usernameCorrecto = "admin";

  const passwordCorrecto = "123456";

  if (user === usernameCorrecto && password === passwordCorrecto) {
      setMensaje("Bienvenido " + user);
  } else {
    setMensaje("Tu no estas autorizado, alertando al FBI");
  }
};


  return (
    <div className="App">
      <Login onGetLogin={getLogin}/>
      {mensaje && <Mensaje mensaje={mensaje} />}
    </div>
  );
}

export default App;
