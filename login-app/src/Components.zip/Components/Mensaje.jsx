import { useEffect, useState } from "react";

const Mensaje = ({ mensaje }) => {

    return <p>{mensaje}</p>;
  
  };
  
  
  export default Mensaje;
