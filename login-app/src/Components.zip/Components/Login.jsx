import { useForm } from "react-hook-form";
import React, { useState } from "react";

function  Login({onGetLogin}) {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const {
    register,
    formState: { errors },
  } = useForm();

  //const onSubmit = (data) => console.log(data);
  const handleSubmit  = (e) => {
    console.log(e);
    e.preventDefault();
    onGetLogin(username, password);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <h3>Bienvenido de vuelta, ingresa tus credenciales</h3>

        <div className="data">
          <div>
            <label>Usuario: </label>
            <input type = "text"
              {...register("username", {
                required: true,
              })}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="errors">
            <label>
              {errors.username?.type === "required" && "Username es requerido"}
            </label>
          </div>
        </div>

        <p></p>

        <div>
          <label>Contraseña: </label>
          <input
            type="password"
            {...register("pass", {
              required: true,
            })}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="errors">
          <label>
            {errors.pass?.type === "required" && "Constraseña es requerida"}
          </label>
        </div>

        <p></p>
        <input type="submit" className="btn-primary" value="Ingresar" />
      </div>
    </form>
  );
};

export default Login;
